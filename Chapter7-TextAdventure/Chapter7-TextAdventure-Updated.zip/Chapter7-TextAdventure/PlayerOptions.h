#pragma once

enum class PlayerOptions
{
	Tell,	//add additional playerOption for new Menu option (common practice for me is to keep these in the same order as they will be written throughout the code, but this is not required)
	Quit,
	None
};