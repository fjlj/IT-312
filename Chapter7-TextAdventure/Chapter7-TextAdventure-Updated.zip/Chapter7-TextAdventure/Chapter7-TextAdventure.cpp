// Chapter7-TextAdventure.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Player.h"
#include "GameLoop.h"

int _tmain(int argc, _TCHAR* argv[])
{
	Game game;
	game.RunGame();

	return 0;
}